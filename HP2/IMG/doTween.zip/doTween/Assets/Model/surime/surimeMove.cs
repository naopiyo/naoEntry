﻿
using UnityEngine;
using System.Collections;
using DG.Tweening;



public class surimeMove : MonoBehaviour {

	public GameObject obj;							//動かすオブジェクト（今はスライムのオブジェクト）
	private Sequence mysequence;					//オブジェクトの動かし方を入れる。
	private Animator animator;						//アニメーションの動かし方を入れる。
	private bool nowmove = false;					//今、次の動作（ダメージがあった場合を除く）ができるかどうか
	private bool death = false;						//死亡しているかどうか
	private const float animeFps = 24;				//FBXファイルのアニメーションのコマ数（1秒に何コマか）

	[SerializeField]
	public AnimationCurve easingWalk;				//モーション時のオブジェクトの動き方（以下同様）
	public AnimationCurve easingRun;
	public AnimationCurve easingKB;
	public AnimationCurve easingKBAirHorizontal;
//	public AnimationCurve easingKBAirVertical;
	public AnimationCurve easingTurn;
	public AnimationCurve easingAttackHorizontal;
	public AnimationCurve easingAttackVertical;

	void Start(){
		animator = GetComponent<Animator>();		//アニメーション遷移の『surimeMove』を取得
	}
		

	/////////////////////////////////////// IdleMove() 動きをリセットしたい時（壁にぶつかった時）に呼びます（アニメーションのリセットではなく動きの終わりです）　//////////		
	public void IdleMove()
	{
		nowmove = false;							//今、次の動作（ダメージがあった場合を除く）ができるかどうか　　できます
		mysequence.Kill (false);					//動きを止める
	}
	////////////////////////////////////////// IdleMove() //////////////////////////////////////////////////
	/////////////////////////////////////// Attack() 攻撃したい時に再生します/////////////////////////////////////////////////////		
	public void Attack()
	{
		if (nowmove == true) {						//今、次の動作ができるかどうかを見て、できる場合は再生します
			return;
		} else {
			nowmove = true;
		}
		//オブジェクトの動かし方を破棄する。
		mysequence.Kill (false);					//前にしていた動きを止めます（多分nullだけど一応）
		//オブジェクトの動かし方を設定する。
		Vector3 dir = myLocalVec();					//自身の向きベクトルを取得します。（単位ベクトルです）
		float moveTime = 65 / animeFps;				//このアニメーションの再生時間と動き方の再生時間の時間を書きます（今回は65Fpsのアニメーションでした）
		mysequence = DOTween.Sequence ()			//動き方を設定します
			.Append (								//Appendで前の動きに次の動きを入れます
				obj.transform.DOMoveZ (transform.position.z + 6 * dir.z, moveTime)				//Z方向に自分の向きベクトルの６倍に『moveTime』秒かけて動きます
				.SetEase (easingAttackHorizontal)				//最初に設定したどんな動きをするのかを設定します
			)
			.Join (									//Joinで前の動きと同時にこの動きをします
				obj.transform.DOMoveX (transform.position.x + 6 * dir.x, moveTime)	//x方向にどれだけ動くか・何秒で動くかを決める
				.SetEase (easingAttackHorizontal)
			)
			.OnStart (() => {						//動きが始まった時に、何かしてほしいことがあったらここに書きます。（mysequenceの操作はできないので注意）
				animator.SetTrigger ("Attack");		//動き方は設定したので、アニメーションの再生するフラグを立てましょう。（詳しくはUnityのアニメーターとかでググりましょう）
			})
			.OnKill (() => {						//動きが終わった時に、何かしてほしいことがあったらここに書きます。
				nowmove = false;					//次の動きがをできることを教えます。
			})
			.Join (
				//rectTransform.DOScale(new Vector3(2f, 2f), 3f).SetDelay(2);
				obj.transform.DOMoveY (transform.position.y + 2, 15/animeFps)	//x方向にどれだけ動くか・何秒で動くかを決める
				.SetEase (easingAttackVertical)
				.SetDelay (20 / animeFps)							//この動きを遅れて再生したい時に呼びます（秒数を入れます）
				.SetLoops(2,LoopType.Yoyo)							//動きを『Yoyo』というDoTweenないの動きで二回再生します（滑らかに上がって下がるジャンプの動きをします）
			);
	}
	////////////////////////////////////////// Attack() //////////////////////////////////////////////////
	/////////////////////////////////////// WalkMove() 歩かせる時に呼び出します/////////////////////////////////////////////////////		
	public void WalkMove()
	{
		if (nowmove == true) {						//今、次の動作ができるかどうかを見て、できる場合は再生します
			return;
		} else {
			nowmove = true;
		}
		mysequence.Kill (false);					//前にしていた動きを止めます（多分nullだけど一応）
		//オブジェクトの動かし方を設定する。
		Vector3 dir = myLocalVec();					//自身の向きベクトルを取得します。（単位ベクトルです）
		float moveTime = 69 / animeFps;				//このアニメーションの再生時間と動き方の再生時間の時間を書きます（今回は69Fpsのアニメーションでした）
		mysequence = DOTween.Sequence()				//動き方を設定します
			.Append(								//Appendで前の動きに次の動きを入れます
				obj.transform.DOMoveZ (transform.position.z + 2 * dir.z, moveTime)				//Z方向に自分の向きベクトルの二倍に『moveTime』秒かけて動きます
				.SetEase (easingWalk)				//最初に設定したどんな動きをするのかを設定します
			).Join(									//Joinで前の動きと同時にこの動きをします
				obj.transform.DOMoveX (transform.position.x + 2 * dir.x, moveTime)
				.SetEase (easingWalk)
			)
			.OnStart (() => {						//動きが始まった時に、何かしてほしいことがあったらここに書きます。（mysequenceの操作はできないので注意）
				animator.SetTrigger ("Walk");		//動き方は設定したので、アニメーションの再生するフラグを立てましょう。（詳しくはUnityのアニメーターとかでググりましょう）
			})
			.OnKill(() => {							//動きが終わった時に、何かしてほしいことがあったらここに書きます。
				nowmove = false;					//次の動きがをできることを教えます。
			});
	}
	////////////////////////////////////////// WalkMove() //////////////////////////////////////////////////
	/////////////////////////////////////// RunMove() 走らせる時に呼び出します/////////////////////////////////////////////////////		
	public void RunMove()
	{
		if (nowmove == true) {
			return;
		} else {
			nowmove = true;
		}
		//オブジェクトの動かし方を破棄する。
		mysequence.Kill (false);
		//オブジェクトの動かし方を設定する。
		Vector3 dir = myLocalVec();
//		float moveTime = 40 / animeFps;
		float moveTime = 2;
		mysequence = DOTween.Sequence()
			.Append(
				obj.transform.DOMoveZ (transform.position.z + 4 * dir.z, moveTime)
				.SetEase (easingRun)									//どんな速度で再生するかを決める
			).Join(
				obj.transform.DOMoveX (transform.position.x + 4 * dir.x, moveTime)	//x方向にどれだけ動くか・何秒で動くかを決める
				.SetEase (easingRun)
			)
			.OnStart (() => {
				animator.SetTrigger ("Run");
			})
			.OnKill(() => {
				nowmove = false;
			});
	}
	////////////////////////////////////////// RunMove() //////////////////////////////////////////////////
	/////////////////////////////////////// KBMove() 地面に接地している時に、ダメージを受けた時に呼び出します/////////////////////////////////////////////////////		
	public void KBMove()
	{
		//オブジェクトの動かし方を破棄する。
		nowmove = true;
		mysequence.Kill (false);
		if (death == true) {
			animator.SetTrigger ("Damage");
			return;
		}
		//オブジェクトの動かし方を設定する。
		Vector3 dir = myLocalVec();
		float moveTime = 35 / animeFps;
		mysequence = DOTween.Sequence()
			.Append(
				obj.transform.DOMoveZ (transform.position.z - 1 * dir.z, moveTime)
				.SetEase (easingKB)									//どんな速度で再生するかを決める
			).Join(
				obj.transform.DOMoveX (transform.position.x - 1 * dir.x, moveTime)	//x方向にどれだけ動くか・何秒で動くかを決める
				.SetEase (easingKB)
			)
			.OnStart (() => {
				animator.SetTrigger ("Damage");
			})
			.OnKill(() => {
				nowmove = false;
			});
	}
	////////////////////////////////////////// KBMove() //////////////////////////////////////////////////
	/////////////////////////////////////// KBAirMove() 空中（攻撃途中）にダメージを受けた時に再生します/////////////////////////////////////////////////////		
	public void KBAirMove()
	{
		//オブジェクトの動かし方を破棄する。
		nowmove = true;
		mysequence.Kill (false);
		if (death == true) {
			animator.SetTrigger ("Damage");
			return;
		}
		//オブジェクトの動かし方を設定する。
		Vector3 dir = myLocalVec();
		float moveTime = 35 / animeFps;
		mysequence = DOTween.Sequence()
			.Append(
				obj.transform.DOMoveZ (transform.position.z - 3 * dir.z, moveTime)
				.SetEase (easingKBAirHorizontal)									//どんな速度で再生するかを決める
			).Join(
				obj.transform.DOMoveX (transform.position.x - 3 * dir.x, moveTime)	//x方向にどれだけ動くか・何秒で動くかを決める
				.SetEase (easingKBAirHorizontal)
			)
			.OnStart (() => {
				animator.SetBool("Air", true );
				animator.SetTrigger ("Damage");
			})
			.OnKill(() => {
				animator.SetBool("Air", false );
				nowmove = false;
			});
	}
	////////////////////////////////////////// KBAirMove() //////////////////////////////////////////////////
	/////////////////////////////////////// TurnRMove() 右に方向転換したい時に再生します/////////////////////////////////////////////////////		
	public void TurnRMove()
	{
		if (nowmove == true ) {
			return;
		} else {
			nowmove = true;
		}
		//オブジェクトの動かし方を破棄する。
		mysequence.Kill (false);
		float moveTime = 38 / animeFps;
		//オブジェクトの動かし方を設定する。
		mysequence = DOTween.Sequence ()
			.Append (
				obj.transform.DORotate (new Vector3 (0f,transform.eulerAngles.y + 30f, 0), moveTime)
				.SetEase (easingTurn)									//どんな速度で再生するかを決める
			)
			.OnStart (() => {
				animator.SetTrigger ("Right");
			})
			.OnKill(() => {
				nowmove = false;
			});
	}
	////////////////////////////////////////// TurnRMove() //////////////////////////////////////////////////
	/////////////////////////////////////// TurnLMove() 左に方向転換したい時に再生します/////////////////////////////////////////////////////		
	public void TurnLMove()
	{
		if (nowmove == true) {
			return;
		} else {
			nowmove = true;
		}
		//オブジェクトの動かし方を破棄する。
		mysequence.Kill (false);
		float moveTime = 38 / animeFps;
		//オブジェクトの動かし方を設定する。
		mysequence = DOTween.Sequence ()
			.Append (
				obj.transform.DORotate (new Vector3 (0f,transform.eulerAngles.y - 30f, 0), moveTime)
				.SetEase (easingTurn)									//どんな速度で再生するかを決める
			)
			.OnStart (() => {
				animator.SetTrigger ("Left");
			})
			.OnKill(() => {
				nowmove = false;
			});
	}
	////////////////////////////////////////// TurnLMove() //////////////////////////////////////////////////
	/////////////////////////////////////// Death() 死亡した時に再生します/////////////////////////////////////////////////////		
	public void Death()
	{
		//オブジェクトの動かし方を破棄する。
		nowmove = true;
		death = true;
		mysequence.Kill (false);
		//オブジェクトの動かし方を設定する。
		animator.SetBool("Death", true );
		animator.SetTrigger ("Damage");
	}
	////////////////////////////////////////// Death() //////////////////////////////////////////////////
	////////////////////////////////////////// ↓はリセット・アニメーション停止（デバック用） ///////////////////
	public void Reset()
	{
		nowmove = false;
		death = false;
		animator.SetTrigger ("Damage");
		animator.SetBool("Death", false );
		mysequence.Kill (false);
		obj.transform.position = new Vector3 (0, 0, 0);
	}
	////////////////////////////////////////// ↓はリセット・アニメーション停止（デバック用） ///////////////////
	////////////////////////////////////////// myLocalVec() 自身の向きベクトル（単位ベクトルを返します）//////////////////////////////////////////////////
	public Vector3 myLocalVec()
	{
		float angleDir = obj.transform.eulerAngles.y * (Mathf.PI / 180.0f);
		Vector3 dir = new Vector3 (Mathf.Sin (angleDir), 0.0f, Mathf.Cos (angleDir));
		return dir;
	}
}
